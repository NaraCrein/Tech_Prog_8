function goToSign(flag) {
    if (flag){
        window.location.href = '../Profile/Profile.html';
    }
    window.location.href = '../Sign/SignIn.html';
}