
function goToSign(flag) {
    if (flag){
        window.location.href = 'profile';
    }
    window.location.href = 'signin';
}

function goToDetail(){
    window.location.href = 'detail';
}
